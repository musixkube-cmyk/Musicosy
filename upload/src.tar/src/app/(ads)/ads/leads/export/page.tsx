"use client";

import Link from "next/link";

export default function Page() {
  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-neutral-900">Export Leads</h1>
          <p className="mt-1 text-sm text-neutral-500">Download leads as CSV or sync to CRM.</p>
        </div>
      </div>

    </div>
  );
}
