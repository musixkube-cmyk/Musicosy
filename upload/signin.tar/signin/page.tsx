"use client";

import { Suspense } from "react";
import SignInForm from "@/components/auth/SignInForm";

/**
 * Marketing portal sign-in / sign-up page (mounted at /signin).
 *
 * Portal-specific wiring:
 *   - redirectTo: /dashboard        (the main user dashboard)
 *   - callbackPath: /auth/callback (Supabase OAuth return URL)
 *
 * Auth flow is identical to the other two portals — see
 * src/components/auth/SignInForm.tsx for the full flow doc.
 */
export default function SignInPage() {
  return (
    <Suspense fallback={null}>
      <SignInForm redirectTo="/dashboard" callbackPath="/auth/callback" />
    </Suspense>
  );
}
