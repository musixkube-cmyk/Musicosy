import type { Metadata } from "next";
import { Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const jetbrains = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-jetbrains",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "MusicOSY — integrated media surface",
    template: "%s — MusicOSY",
  },
  description:
    "MusicOSY is a single integrated surface for music, podcasts, live rooms and creator workflow. Playback survives every route change.",
  openGraph: {
    title: "MusicOSY",
    description:
      "One persistent media session across home, scroll, discover, listen, live, library and search.",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${inter.variable} ${jetbrains.variable}`}>
      <head>
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"
        />
        <style>{`
          :root {
            --font-body-sm: "Inter", sans-serif;
            --font-headline-sm: "Inter", sans-serif;
            --font-headline-md: "Inter", sans-serif;
            --font-display-lg: "Inter", sans-serif;
            --font-body-lg: "Inter", sans-serif;
            --font-mono-data: "JetBrains Mono", monospace;
            --font-label-caps: "JetBrains Mono", monospace;
          }
        `}</style>
      </head>
      <body>{children}</body>
    </html>
  );
}
