import { AppShellProvider } from "@/state/app-shell";
import { TopRail, MobileRail } from "@/components/shell/TopRail";
import { RightRail } from "@/components/shell/RightRail";
import { PlayerRail } from "@/components/shell/PlayerRail";
import { SearchPalette, OverlayHost } from "@/components/shell/Overlays";

export default function ShellLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <AppShellProvider>
      <div className="min-h-screen bg-background">
        <TopRail />
        <main className="min-h-screen px-gutter pb-[152px] pt-[72px] lg:pr-[calc(var(--width-rail-right-width)+var(--spacing-gutter))] xl:pb-[88px]">
          {children}
        </main>
        <RightRail />
        <PlayerRail />
        <MobileRail />
        <SearchPalette />
        <OverlayHost />
      </div>
    </AppShellProvider>
  );
}
