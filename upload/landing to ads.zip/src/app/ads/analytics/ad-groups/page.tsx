export default function AdGroupsPage() {
  return (
    <div>
      <h1 className="font-display text-2xl font-bold tracking-tight text-neutral-900">Ad Groups</h1>
      <p className="mt-2 text-sm text-neutral-500">This page is under construction.</p>
    </div>
  );
}
